import React from 'react';
import { BrowserRouter } from "react-router-dom";
import { Routes, Route } from "react-router";
import Tuiter from './tuiter';

function App() {

  return (
    <BrowserRouter>
    <div className="container">
    <Routes>
      <Route index element={<Tuiter/>}/>
      <Route path="/tuiter/*" element={<Tuiter/>}/>
    </Routes>
    </div>
    </BrowserRouter>

  );
}

export default App;