import React from "react";
import TuitsList from "../tuits-list";
import WhatsHappening from "./whats-happening";

const HomeComponent = () => {
    return(
        <>
        <h4 className="fw-bold">Home </h4>
        <WhatsHappening/>
        <TuitsList/>
        </>
    );
};
export default HomeComponent;