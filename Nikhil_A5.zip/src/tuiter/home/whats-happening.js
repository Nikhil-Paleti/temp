import React, {useState} from "react";
import {createTuit} from "../reducers/tuits-reducer";
import {useDispatch} from "react-redux";


const WhatsHappening = () => {
let [whatsHappening, setWhatsHappening] = useState('');
const dispatch = useDispatch();

const tuitClickHandler = () => {
    const newTuit = {
        tuit: whatsHappening
        }
        dispatch(createTuit(newTuit));
}


return (
    <div className="card mb-2">
        <div className="card-body">
            <div className="row">
                <div className="col-auto">
                    <img src="https://assets.stickpng.com/images/58429400a6515b1e0ad75acc.png" width={60} alt="User Avatar"/>
                </div>
                <div className="col">
                    <textarea 
                        value={whatsHappening} 
                        placeholder="What's happening?" 
                        className="form-control border-0" 
                        onChange={(event) => setWhatsHappening(event.target.value)}
                    ></textarea>
                </div>
            </div>
            <div className="row mt-2">
                <div className="col-auto">
                    <div className="text-primary fs-2">
                        <i className="bi bi-card-image me-3"></i>
                        <i className="bi bi-filetype-gif me-3"></i>
                        <i className="bi bi-bar-chart me-3"></i>
                        <i className="bi bi-emoji-smile me-3"></i>
                        <i className="bi bi-geo-alt"></i>
                    </div>
                </div>
                <div className="col text-end">
                    <button 
                        className="rounded-pill btn btn-primary ps-3 pe-3 fw-bold"
                        onClick={tuitClickHandler}
                    >
                        Tuit
                    </button>
                </div>
            </div>
        </div>
    </div>
);


}
export default WhatsHappening;
