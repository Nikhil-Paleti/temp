import React from 'react';
import {Link} from "react-router-dom";
import {useLocation} from "react-router";


const NavigationSidebar = () => {

    const {pathname} = useLocation();
    const paths = pathname.split('/')
    let active = paths[2];

    if (!active) {
        active = "home";
    }

    return (
        <div className='list-group'>
            <a className='list-group-item'><i class="fab fa-twitter "></i><span class="d-none d-sm-inline"> Tuiter</span> </a>

            <Link to="/tuiter/home" className={`list-group-item ${active === 'home'?'active':''}`}> <i class="fa fa-home"></i> <span class="d-none d-sm-inline"> Home</span> </Link>
            <Link to="/tuiter/explore" className={`list-group-item ${active === 'explore'?'active':''}`}> <i class="fa fa-hashtag"></i> <span class="d-none d-sm-inline"> Explore</span> </Link>
            <a className={`list-group-item  ${active === 'notifications'?'active':''}`}><i class="fa fa-bell"></i> <span class="d-none d-sm-inline"> Notifications</span> </a>
            <a className={`list-group-item  ${active === 'messages'?'active':''}`}><i class="fa fa-envelope"></i> <span class="d-none d-sm-inline"> Messages</span> </a>
            <a className={`list-group-item  ${active === 'bookmarks'?'active':''}`}><i class="fa fa-bookmark"></i> <span class="d-none d-sm-inline"> Bookmarks</span> </a>
            <a className={`list-group-item  ${active === 'lists'?'active':''}`}><i class="fa fa-list"></i> <span class="d-none d-sm-inline"> Lists</span> </a>
            <a className={`list-group-item  ${active === 'profile'?'active':''}`}><i class="fa fa-user"></i> <span class="d-none d-sm-inline"> Profile</span> </a>
            <a className={`list-group-item  ${active === 'more'?'active':''}`}><i class="fa fa-ellipsis-h"></i> <span class="d-none d-sm-inline"> More</span> </a>
        </div>
    );
};

export default NavigationSidebar;