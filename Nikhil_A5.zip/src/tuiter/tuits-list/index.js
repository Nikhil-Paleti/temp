import React from "react";
import TuitItem from "./tuit-item";
import { useSelector } from "react-redux";

const TuitsList = () => {
    // Using the useSelector hook to get the tuits from the Redux state
    const postsArray = useSelector((state) => state.tuits);

    return (
        <ul className="list-group">
            {
                // Mapping over the postsArray to render each post with the TuitItem component
                postsArray.map((post) => (
                    <TuitItem 
                        key={post._id}
                        post={post}
                    />
                ))
            }
        </ul>
    );
};

export default TuitsList;
