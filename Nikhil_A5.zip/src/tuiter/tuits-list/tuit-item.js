import React from 'react';
import TuitStats from './tuit-stats'; // Import the TuitStats component
import {useDispatch} from "react-redux";
import { deleteTuit } from '../reducers/tuits-reducer'; 

const TuitItem = ({ post }) => {

    const dispatch = useDispatch();

    const deleteTuitHandler = (id) => {
    dispatch(deleteTuit(id));
    }

    return (
        <li className='list-group-item'>
            <div className='row'>
                <div className='col-2'>
                    <img width={50} className='rounded-circle' src={post.image} alt={post.userName} />
                </div>
                <div className='col-10'>
                    <div className='fw-bolder'>
                        {post.userName} 
                        <span className='text-muted'>· {post.handle} · {post.time}</span>
                        <i className="bi bi-x-lg float-end" onClick={() => deleteTuitHandler(post._id)}></i> 
                    </div>
                    <div>{post.tuit}</div>
                    <TuitStats post={post} /> 
                </div>
            </div>
        </li>
    );

};

export default TuitItem;
