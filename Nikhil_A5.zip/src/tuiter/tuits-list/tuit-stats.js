import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faComment, faRetweet, faHeart, faShare } from '@fortawesome/free-solid-svg-icons';
import { useDispatch, useSelector } from 'react-redux';
import { likeTuit, unlikeTuit } from '../reducers/tuits-reducer'; 

const TuitStats = ({ post }) => {
    const dispatch = useDispatch();
    const tuit = useSelector(state => state.tuits.find(t => t._id === post._id));

    const handleLikeClick = () => {
        if (tuit.liked) {
            dispatch(unlikeTuit(tuit._id));
        } else {
            dispatch(likeTuit(tuit._id));
        }
    };

    const baseIconStyle = {
        color: 'white',
        stroke: 'black',
        strokeWidth: '1em',
        cursor: 'pointer'
    };

    const likedColor = tuit.liked ? 'red' : 'white';
    const textColor = tuit.liked ? 'red' : 'black';

    return (
        <div className='row mt-2'>
            <div className='col-3'>
                <span><FontAwesomeIcon icon={faComment} style={baseIconStyle} /> {post.replies}</span>
            </div>
            <div className='col-3'>
                <span><FontAwesomeIcon icon={faRetweet} style={baseIconStyle} /> {post.retuits}</span>
            </div>
            <div className='col-3'>
                <span 
                    onClick={handleLikeClick}
                    style={{ color: textColor }}
                >
                    <FontAwesomeIcon 
                        icon={faHeart} 
                        style={{ 
                            ...baseIconStyle, 
                            color: likedColor
                        }}
                    /> {tuit.likes}
                </span>
            </div>
            <div className='col-3'>
                <span><FontAwesomeIcon icon={faShare} style={baseIconStyle} /></span>
            </div>
        </div>
    );
};

export default TuitStats;
