import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

import React from 'react';
import ExploreComponent from './explore';
import HomeComponent from "./home";
import NavigationSidebar from './navigation-sidebar';
import WhoToFollowList from './who-to-follow-list';

import whoReducer from './reducers/who-reducer';
import tuitsReducer from "./reducers/tuits-reducer";
import { configureStore } from '@reduxjs/toolkit';
import { Provider } from 'react-redux';
import {Routes, Route} from "react-router";

const store = configureStore({
  reducer: {
    who: whoReducer,
    tuits: tuitsReducer,
  }
});

function Tuiter() {
  return (

    <Provider store={store}>
      
   <div class="container-fluid">

        <div class="row align-self-center justify-content-center mt-3 mb-5">

      <div className="col-2 col-md-3 col-lg-2 col-xl-2 ms-5">
      <NavigationSidebar/>
      </div>
   
      <div className="col-7 col-sm-7 col-md-7 col-lg-7 col-xl-5"
      style={{"position": "relative"}}>

      <Routes>
      <Route index
      element={<HomeComponent/>}/>
      <Route path="/home" element={<HomeComponent/>}/>
      <Route path="/explore" element={<ExploreComponent/>}/>
      </Routes>

      </div>
      
      <div className="d-sm-none d-md-none d-lg-block col-lg-4 col-xl-3">
      <WhoToFollowList/>
      </div>


        </div>
   </div>

   </Provider>
  
  );
  }

export default Tuiter
