import React from 'react';
import "./index.css";
import PostSummaryList from "../post-summary-list";

const ExploreComponent = () => {
    return (
        <>
        <div className='row'>

            <div className='col-11 position-relative'>
                <input placeholder='Search Tuiter'
                className='form-control rounded-pill ps-5'/>
                <i className='bi bi-search position-absolute wd-nudge-up'></i>
            </div>
            
            <div className='col-1'>
                <i className='wd-bottom-4 text-primary float-end bi bi-gear-fill fs-2 position-relative'></i>
            </div>
        </div>

        <ul className='nav nav-pills mb-2'>
            <li className='nav-item'>
                <a className='nav-link active'>For You</a>
            </li>
            <li className='nav-item'>
                <a className='nav-link'>Trending</a>
            </li>
            <li className='nav-item'>
                <a className='nav-link'>News</a>
            </li>
        </ul>

        <div className='positive-relative mb-2' style={{ position: 'relative' }}>
            <img src="https://techcrunch.com/wp-content/uploads/2019/09/Starship-Mk1-Day.jpg" className='w-100' />
            <h1 className='position-absolute wd-nudge-up text-white' style={{ top: '-1', left: '0', padding: '10px' }}>SpaceX Starship</h1>
        </div>

        <div>

        <PostSummaryList/>
        
        </div>
        
        </>
    )
}

export default ExploreComponent;