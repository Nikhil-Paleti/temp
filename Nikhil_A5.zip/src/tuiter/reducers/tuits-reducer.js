import {createSlice} from '@reduxjs/toolkit';
import tuits from '../data/tuits.json';


const currentUser = {
    "userName": "NASA",
    "handle": "@nasa",
    "image": "https://assets.stickpng.com/images/58429400a6515b1e0ad75acc.png",
    };
    
    const templateTuit = {
    ...currentUser,
    "Title" : "Posted by you",
    "topic": "Space",
    "time": "2h",
    "liked": false,
    "replies": 0,
    "retuits": 0,
    "likes": 0,
    }

    
const tuitsSlice = createSlice({
    name: 'tuits',
    initialState: tuits,
    reducers: {
    deleteTuit(state, action) {
        const index = state
        .findIndex(tuit =>
        tuit._id === action.payload);
        state.splice(index, 1);
        },
           
    createTuit(state, action) {
    state.unshift({
    ...action.payload,
    ...templateTuit,
    _id: (new Date()).getTime(),
    })
    },

    likeTuit(state, action) {
        const tuit = state.find(t => t._id === action.payload);
        if (tuit) {
            tuit.liked = true;
            tuit.likes += 1;
        }
    },
    unlikeTuit(state, action) {
        const tuit = state.find(t => t._id === action.payload);
        if (tuit) {
            tuit.liked = false;
            tuit.likes -= 1;
        }
    }


   }
   });

   export const {createTuit, deleteTuit, likeTuit, unlikeTuit} = tuitsSlice.actions;

export default tuitsSlice.reducer;