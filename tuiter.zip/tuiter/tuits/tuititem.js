import React from "react";
import { useDispatch } from "react-redux";
import { deleteTuit } from "../reducers/tuits.reducer";

const TuitItem = (
    {
        tuit = 
        {
            "topic": "Space",
            "userName": "SpaceX",
            "time": "2h",
            "title": "Tesla Cybertruck lands on Mars and picks up the Curiosity rover on its 6' bed",
            "image": "https://assets.materialup.com/uploads/922c35bd-940d-4f26-bbd5-ff8b7075f53b/preview.jpg",
            "liked": true,
            "replies": 10,
            "retuits": 10,
            "likes": 1234,
            "handle": "@spacex",
            "tuit": "SpaceX tuit text here",
        }
    }
) => {
    const dispatch = useDispatch();
    const deleteTuitHandler = (id) => {
        dispatch(deleteTuit(id));
    }
  return (
    <li className="list-group-item">
      <div className="row">
        <div className="col-auto">
          <img
            src={tuit.image}
            width={50}
            alt={tuit.userName}
            className="float-end rounded-circle"
          />
        </div>
        <div className="col-10">
          <div>
            <i className="bi bi-x-lg float-end
            "onClick={() => deleteTuitHandler(tuit._id)}></i>
            {/* <h5 className="mb-1">{tuit.userName}<span className="text-muted small">{tuit.handle}</span></h5> */}
            <div>
            <h5 className="mb-1">
              <span className="me-1">{tuit.userName} </span>
              <span className="text-muted small">{tuit.handle}</span>  
              <small className="text-muted"> . {tuit.time}</small>
            </h5>
            </div>
            
          </div>
          <p className="mb-2">{tuit.tuit}</p>
          {/* <p className="text-muted">{tuit.topic}</p> */}
          <div className="d-flex justify-content-between">
            {/* <p className="text-muted">{tuit.topic}</p> */}
            <div className="d-flex">
              <div className="d-flex align-items-center me-5">
                <i className="bi bi-chat me-2"></i> {tuit.replies}
              </div>
              <div className="d-flex align-items-center me-5">
                <i className="bi bi-arrow-repeat me-2"></i> {tuit.retuits}
              </div>
              <div className="d-flex align-items-center me-5">
                <i className={`bi bi-heart${tuit.liked ? '-fill text-danger' : ''} me-2`}></i> {tuit.likes}
              </div>
              <div className="d-flex align-items-center">
                <i className="bi bi-share"></i>
              </div>
            </div>
          </div>

        </div>
      </div>
    </li>
  );
};

export default TuitItem;
