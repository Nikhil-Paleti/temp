import React from "react";
import TuitItem from "./tuititem"; // Import your TuitItem component

const TuitsList = ({ tuits }) => {
  return (
    <ul className="list-group">
      {tuits.map((tuit) => (
        <TuitItem key={tuit._id} tuit={tuit} />
      ))}
    </ul>
  );
};

export default TuitsList;
