import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import NavigationSidebar from './navigation-sidebar';
import WhoToFollowList from './who-to-follow-list';
import ExploreComponent from './explore';
import Home from './home';

import whoReducer from './reducers/who-reducer';
import { configureStore } from '@reduxjs/toolkit';
import { Provider } from 'react-redux';

import tuitsReducer from './reducers/tuits.reducer';

const store = configureStore({
  reducer: {
    who: whoReducer, 
      tuits: tuitsReducer
  }
});

function Tuiter() {
  return (
   <Provider store={store}>
      <div className="container-fluid">
      <div class="row align-self-center justify-content-center mt-5">
         <div className="col-2 col-md-3 col-lg-1 col-xl-2 ms-5">
            <NavigationSidebar active="home"/>
         </div>
   
         <div className="col-6 col-md-6 col-lg-3 col-xl-4" style={{"position": "relative"}}>
            {/* <ExploreComponent/> */}
            <Home/>
         </div>
      
         <div className="d-sm-none d-md-none d-lg-block col-lg-4 col-xl-3">
            <WhoToFollowList/>
         </div>
      </div>
   </div>
   </Provider>
  );
  }
  export default Tuiter
