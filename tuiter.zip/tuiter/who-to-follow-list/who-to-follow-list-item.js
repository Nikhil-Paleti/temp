import React from 'react';
const WhoToFollowListItem = (
    {
        who = { userName: "NASA", handle: "NASA", avatarIcon: "https://www.lentechinc.com/test/wp-content/uploads/2017/05/Nasa-Logo.jpg",
                userName: "Tesla", handle: "tesla", avatarIcon: "https://assets.materialup.com/uploads/922c35bd-940d-4f26-bbd5-ff8b7075f53b/preview.jpg",
                userName: "SpaceX", handle: "spacex", avatarIcon: "https://www.spacex.com/static/images/share.jpg"}
    }

) => {
    return (
        <div className='list-group'>
            <a className='list-group-item'>
            <div className='row'>
                <div className='col-2'>
                    <img className='rounded-circle' height={48} src={who.avatarIcon}/>
                </div>
                <div className='col-8'>
                    <div className='fw-bold'>{who.userName}</div>
                    <div>@{who.handle}</div>
                </div>
                <div className='col-2'>
                    <button className='btn btn-primary rounded-pill float-end'>Follow</button>
                </div>
            </div>
            </a>

        </div>
    );
};

export default WhoToFollowListItem;