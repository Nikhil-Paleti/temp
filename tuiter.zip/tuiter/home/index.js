import React from "react";
import { useSelector } from "react-redux";
import TuitsList from "../tuits/tuits-list";
import WhatsHappening from "./whats-happening";

const Home = () => {
  // Use useSelector to get the list of tuits from the Redux store
  const tuits = useSelector((state) => state.tuits);

  return (
    <div>
      <h4>Home</h4>
      <WhatsHappening />
      <TuitsList tuits={tuits} />
    </div>
  );
};

export default Home;
